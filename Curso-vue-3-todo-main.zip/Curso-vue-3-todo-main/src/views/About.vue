<template>
    <About/>
</template>

<script setup>
import About from '@/components/about/About.vue'
</script>
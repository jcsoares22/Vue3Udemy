<template>
  <TodoList/>
</template>

<script setup>
  import TodoList from '@/components/TodoList.vue'
</script>

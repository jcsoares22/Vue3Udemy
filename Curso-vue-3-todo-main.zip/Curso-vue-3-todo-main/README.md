# Curso de Vue 3 Com Vuetify e 3 projetos.

![Captura de Tela 2023-11-13 às 02 36 50](https://github.com/yurimarcon/Curso-vue-3-todo/assets/44410208/cfc67939-5d0e-4fd5-a7ea-b18a2834ffee)


## Project setup

```
# yarn
yarn

# npm
npm install

# pnpm
pnpm install

# bun
bun install
```

### Compiles and hot-reloads for development

```
# yarn
yarn dev

# npm
npm run dev

# pnpm
pnpm dev

# bun
bun run dev
```

### Compiles and minifies for production

```
# yarn
yarn build

# npm
npm run build

# pnpm
pnpm build

# bun
bun run build
```

### Customize configuration

See [Configuration Reference](https://vitejs.dev/config/).
